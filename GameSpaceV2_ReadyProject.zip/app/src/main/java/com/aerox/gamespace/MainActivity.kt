package com.aerox.gamespace

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.provider.Settings
import android.view.Gravity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var results: TextView
    private val permissionCode = 4421
    private val mlbbPackage = "com.mobile.legends"

    private val permissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == permissionCode) {
                updateStatus(if (grantResult == PackageManager.PERMISSION_GRANTED)
                    "Shizuku permission granted." else "Shizuku permission denied.")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 12, 24)
        window.navigationBarColor = Color.rgb(7, 12, 24)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildScreen()
        updateStatus("Ready. Make sure Shizuku is running.")
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(24))
            setBackgroundColor(Color.rgb(7, 12, 24))
        }
        val scroll = ScrollView(this).apply { addView(page) }
        page.addView(TextView(this).apply {
            text = "GAME SPACE V2"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }, fullWidth())
        page.addView(TextView(this).apply {
            text = "REAL CHECKS • BEST-EFFORT OPTIMIZATION"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(100, 190, 255))
            setPadding(0, dp(6), 0, dp(20))
        }, fullWidth())
        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            setBackgroundColor(Color.rgb(23, 32, 51))
        }
        page.addView(status, fullWidth())

        page.addView(section("SHIZUKU"))
        page.addView(button("Request / Check Shizuku Permission") { requestPermission() })
        page.addView(button("Check Device & MLBB Settings") { checkDevice() })

        page.addView(section("DISPLAY REQUESTS"))
        page.addView(button("Try 60 Hz") { requestRefresh(60) })
        page.addView(button("Try 90 Hz") { requestRefresh(90) })
        page.addView(button("Try 120 Hz") { requestRefresh(120) })
        page.addView(button("Reset Refresh-Rate Overrides") { resetRefresh() })
        page.addView(button("Open Display Settings") {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        })

        page.addView(section("MLBB"))
        page.addView(button("Try Android Game Mode: Performance") { tryGameMode() })
        page.addView(button("Open MLBB") {
            val launch = packageManager.getLaunchIntentForPackage(mlbbPackage)
            if (launch == null) append("MLBB app was not found.")
            else startActivity(launch)
        })

        page.addView(section("OUTPUT"))
        results = TextView(this).apply {
            text = "Tap Check Device & MLBB Settings to begin."
            textSize = 12f
            setTextColor(Color.rgb(215, 226, 242))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(16, 22, 36))
        }
        page.addView(results, fullWidth())
        page.addView(TextView(this).apply {
            text = "LIMITS: Shizuku is not root. Android/Vivo may ignore these requests, and MLBB controls its own FPS cap. This app does not unlock unsupported FPS or measure rendered in-game FPS yet. Verify results independently."
            textSize = 12f
            setTextColor(Color.rgb(255, 204, 120))
            setPadding(0, dp(16), 0, dp(8))
        }, fullWidth())
        setContentView(scroll)
    }

    private fun section(label: String) = TextView(this).apply {
        text = label; textSize = 12f
        setTextColor(Color.rgb(100, 190, 255))
        setPadding(0, dp(20), 0, dp(8))
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(29, 75, 135)))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }
    }

    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun updateStatus(message: String) { if (::status.isInitialized) status.text = message }
    private fun append(message: String) {
        if (::results.isInitialized) results.text =
            (results.text.toString() + "\n\n" + message).takeLast(12000)
    }

    private fun shizukuReady(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Exception) { false }

    private fun requestPermission() {
        if (!Shizuku.pingBinder()) {
            updateStatus("Shizuku service is not running. Start it in Shizuku.")
        } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            updateStatus("Shizuku is connected and permission is granted.")
        } else {
            Shizuku.requestPermission(permissionCode)
            updateStatus("Permission request sent. Approve it in Shizuku.")
        }
    }

    private fun shell(command: String, callback: (String) -> Unit) {
        if (!shizukuReady()) {
            updateStatus("Start Shizuku and grant this app permission first.")
            return
        }
        Thread {
            val text = try {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val exit = process.waitFor()
                "Command: $command\nExit code: $exit\nOutput: ${stdout.ifBlank { "(none)" }.trim()}" +
                    if (stderr.isNotBlank()) "\nError: ${stderr.trim()}" else ""
            } catch (e: Exception) { "Command failed: ${e.javaClass.simpleName}: ${e.message}" }
            runOnUiThread { callback(text) }
        }.start()
    }

    private fun checkDevice() {
        shell("getprop ro.build.version.release; settings get system peak_refresh_rate; " +
            "settings get system min_refresh_rate; settings get system user_refresh_rate; " +
            "cmd game list; cmd game mode $mlbbPackage") {
            updateStatus("Check complete. Settings output is not proof of active FPS.")
            append("DEVICE / MLBB CHECK\n$it")
        }
    }

    private fun requestRefresh(hz: Int) {
        shell("settings put system peak_refresh_rate ${hz}.0; " +
            "settings put system min_refresh_rate ${hz}.0; " +
            "settings get system peak_refresh_rate; settings get system min_refresh_rate") {
            updateStatus("Requested $hz Hz. Verify the active display mode separately.")
            append("REFRESH REQUEST: $hz Hz\n$it\nThe device may ignore or override this request.")
        }
    }

    private fun resetRefresh() {
        shell("settings delete system peak_refresh_rate; settings delete system min_refresh_rate; " +
            "settings delete system user_refresh_rate; settings get system peak_refresh_rate; " +
            "settings get system min_refresh_rate") {
            updateStatus("Reset request completed. Re-check display settings.")
            append("RESET REQUEST\n$it")
        }
    }

    private fun tryGameMode() {
        shell("cmd game mode performance $mlbbPackage") {
            updateStatus("Game Mode request sent. Review output.")
            append("ANDROID GAME MODE REQUEST\n$it\nMay be unsupported and does not guarantee higher FPS.")
        }
    }
}

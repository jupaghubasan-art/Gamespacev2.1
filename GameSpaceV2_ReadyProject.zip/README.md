# Game Space V2 — Vivo Y05 / MLBB

Starter Android app using Shizuku for best-effort system settings checks and requests.

## Build an APK from GitHub on a phone
1. Upload all files and folders from this project to the root of your GitHub repository, preserving the folder structure.
2. Open the repository's Actions tab.
3. Choose **Build Game Space V2 APK** and tap **Run workflow**, or push a commit to `main`.
4. When the workflow succeeds, open its run and download the `GameSpaceV2-debug` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Features
- Shizuku service and permission check.
- Best-effort refresh-rate setting requests and reset.
- Best-effort Android Game Mode request for `com.mobile.legends`.
- Shows command output/errors.

## Limitations
- Does not measure true rendered in-game FPS yet.
- Cannot guarantee or unlock unsupported MLBB FPS.
- Reading a setting back does not prove the display/game uses that rate.
- Vivo firmware may ignore commands; Shizuku is not root.
- This workflow builds a debug APK; release signing is not configured.
